// Placeholder untuk global client JS jika perlu
